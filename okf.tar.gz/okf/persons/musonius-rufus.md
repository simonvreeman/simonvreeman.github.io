---
type: Person
title: Musonius Rufus
description: "Roman Stoic philosopher who taught and trained Epictetus, launching his career while Epictetus was still a slave."
resource: https://www.wikidata.org/wiki/Q350937
tags: [stoicism, person]
timestamp: 2026-06-21T19:01:55.548Z
sameAs: https://www.wikidata.org/wiki/Q350937
---
# Musonius Rufus

Roman Stoic philosopher who taught and trained Epictetus, launching his career while Epictetus was still a slave.

## Related

- Related to [Stoicism](../concepts/stoicism.md).
- Precedes [Epictetus](./epictetus.md).

## Examples

> The turning point in his life was his adoption by Musonius Rufus, the very best teacher of philosophy in first-century Rome. Though Epictetus was still technically a slave, Rufus, an Etruscan knight, took him as a student. [1]

## Citations

[1] [The Stoic Warrior's Triad: Tranquility, Fearlessness and Freedom - James Stockdale](https://vreeman.com/stockdale/stoic-warriors-triad)
